const Input = ({title,input}) =>{
    return(
        <div className="form__group">
            <label className="form__label">{title}</label>
            <input className="form__input" name={input}/>
        </div>
    )
}

export default Input;