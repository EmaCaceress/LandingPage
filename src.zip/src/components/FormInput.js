import Input from "./Input";

const FormInput = ({inputs}) =>{
    return(
        <form className="form" action="/api/email" method="post">
            {
                inputs.map(obj=><Input title={obj.title} input={obj.input}/>)
            } 
            <button className="form__button" type="submit">Enviar</button>
        </form>
    )
}

export default FormInput;