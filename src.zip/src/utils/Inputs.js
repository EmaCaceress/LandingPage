export const inputs=[
    {
        title:"Nombre",
        input:"name",
    },
    {
        title:"apellido",
        input:"last-name",
    },
    {
        title:"Telefono",
        input:"phone",
    },
    {
        title:"Correo electronico",
        input:"email",
    },
    {
        title:"Nota",
        input:"note",
    }
]

